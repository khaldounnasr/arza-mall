# Arza Mall – Beginner GitHub Starter (Web-only)
Use this with ONLY the GitHub website (no terminal needed).

Contents:
- .github/ISSUE_TEMPLATE/  → adds 'User Story' and 'Bug Report' templates
- docs/labels.json (reference only)
- docs/issues_copy_paste.txt → 12 ready stories to copy into GitHub Issues
