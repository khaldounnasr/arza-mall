---
name: User Story
about: Create a new user story for Arza Mall
title: ""
labels: "Product Backlog"
assignees: ""
---

**As a** [type of user]  
**I need** [some goal or feature]  
**So that** [business value]

### Acceptance Criteria (Gherkin)
```gherkin
Given [context]
When  [action]
Then  [expected outcome]
```

**Estimate:** [1|3|5] points
